Github Link: https://github.com/jingyu-xie/TicTacToe

# TicTacToe
1. Click TicTacToee.exe to run the game
2. Click start
3. Toggle to set game:
	##PVE##
	- on: PVE Mode
	- off: PVP Mode
	##Go First##
	- on: you move first
	- off: you move second
4. Play the game!